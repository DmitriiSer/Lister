angular-drop-bower
==================

Bower repository for [angular-drop](http://github.com/caitp/angular-drop), a fancy little Angular.js 1.x module for simple drag and drop interactions.

See the main repository for information about contributing and improving the library or its documentation.

To install angular-drop from bower, simply run:

```bash
bower install angular-drop --save
```

This should do it for you.
